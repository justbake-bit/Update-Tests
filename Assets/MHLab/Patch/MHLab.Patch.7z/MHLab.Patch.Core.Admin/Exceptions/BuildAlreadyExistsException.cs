﻿using System;

namespace MHLab.Patch.Core.Admin.Exceptions
{
    public sealed class BuildAlreadyExistsException : Exception
    {
    }
}

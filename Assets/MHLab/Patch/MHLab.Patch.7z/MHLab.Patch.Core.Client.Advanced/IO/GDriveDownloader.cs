﻿using MHLab.Patch.Core.Client.IO;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MHLab.Patch.Core.Client.Advanced.IO
{
    public class GDriveDownloader : FileDownloader
    {
        public string FolderId = "12VvTPs421f4GhLkMTQOfDX4WsTWW0c3D";
        public string ApiKey = "AIzaSyBtWENcNQ7ury6Tk11q4sLNO8l7B8dcz4g";
        
        private string FolderContentUri => $"https://www.googleapis.com/drive/v3/files?q='{FolderId}'+in+parents&key={ApiKey}";
        
        public override void Download(List<DownloadEntry> entries, Action<DownloadEntry> onEntryCompleted)
        {
            entries.Sort((entry1, entry2) =>
            {
                return entry1.Definition.Size.CompareTo(entry2.Definition.Size);
            });

            var fileMap = GetFileIds();
            
            var queue = new ConcurrentQueue<DownloadEntry>(entries);

            var tasksAmount = Environment.ProcessorCount - 1;
            var tasks = new Task[tasksAmount];

            for (var i = 0; i < tasksAmount; i++)
            {
                tasks[i] = Task.Run(() =>
                {
                    using (var client = new WebClient())
                    {
                        while (queue.TryDequeue(out var entry))
                        {
                            int retriesCount = 0;

                            while (retriesCount < MaxDownloadRetries)
                            {
                                try
                                {
                                    client.DownloadFile(entry.RemoteUrl, entry.DestinationFile);

                                    retriesCount = MaxDownloadRetries;
                                }
                                catch
                                {
                                    retriesCount++;

                                    if (retriesCount >= MaxDownloadRetries)
                                    {
                                        throw new WebException($"All retries have been tried for {entry.RemoteUrl}.");
                                    }
                                }
                            }

                            onEntryCompleted?.Invoke(entry);
                        }
                    }
                });
            }

            Task.WaitAll(tasks);
        }

        private Dictionary<string, string> GetFileIds()
        {
            var nextPageToken = string.Empty;
            var uri = FolderContentUri;
            var fileMap = new Dictionary<string, string>();
            
            using (var client = new HttpClient())
            {
                do
                {
                    var pagedUri = uri;
                    if (!string.IsNullOrWhiteSpace(nextPageToken))
                    {
                        pagedUri += $"&pageToken={nextPageToken}";
                    }

                    var serializedContent = client.GetStringAsync(pagedUri).Result;

                    var deserializedContent = (JObject) JsonConvert.DeserializeObject(serializedContent);

                    nextPageToken = (string) deserializedContent["nextPageToken"];

                    foreach (var fileEntry in (JArray)deserializedContent["files"])
                    {
                        var fileId = (string) fileEntry["id"];
                        var fileName = (string) fileEntry["name"];

                        fileMap.Add(fileName, fileId);
                    }
                } while (!string.IsNullOrWhiteSpace(nextPageToken));
            }

            return fileMap;
        }
    }
}

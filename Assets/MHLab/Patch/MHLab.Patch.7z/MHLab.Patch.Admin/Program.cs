﻿namespace MHLab.Patch.Admin
{
    class Program
    {
        static void Main(string[] args)
        {
            var commandline = new AdminCommandLine();
            commandline.Handle(args);
        }
    }
}

﻿using System;

namespace MHLab.Patch.Core.Client.Exceptions
{
    public sealed class NoAvailableBuildsException : Exception
    {
    }
}

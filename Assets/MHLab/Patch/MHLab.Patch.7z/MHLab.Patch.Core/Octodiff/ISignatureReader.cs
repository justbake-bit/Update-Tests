﻿namespace MHLab.Patch.Core.Octodiff
{
    internal interface ISignatureReader
    {
        Signature ReadSignature();
    }
}
﻿namespace MHLab.Patch.Core
{
    public enum PatchOperation
    {
        Unchanged,
        Deleted,
        Updated,
        ChangedAttributes,
        Added
    }
}
